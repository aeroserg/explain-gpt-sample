import { Loader } from "@/libs/ui";

export const SuspenseFallback = () => (
  <div className="flex justify-center items-center h-screen">
    <Loader />
  </div>
);
